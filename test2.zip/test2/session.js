var session = require('express-session');

router.use(session({
    secret: 'admin', // 对session id 相关的cookie 进行签名
    resave: true,
    saveUninitialized: false, // 是否保存未初始化的会话
    cookie: {
        maxAge: 1000 * 60 * 30, // 设置 session 的有效时间，单位毫秒
    },
}));

 
function get() {
    req.session.adminname = "xbq";
    console.log(req.session.adminname);
}
 
exports.start = start;
