
var server = require("./server");
var router = require("./router");
 

var test = require("./test");
 
server.start(router.route);

test.start(router.route);
